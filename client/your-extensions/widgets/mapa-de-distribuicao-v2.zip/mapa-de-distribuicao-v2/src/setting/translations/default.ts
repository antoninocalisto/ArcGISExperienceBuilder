export default {
  _widgetLabel: 'map-distribuition',
  lat: 'Latitude: ',
  lon: 'Longitude: ',
  zoom: 'Zoom',
  latLonWillBeHere: 'Lat/Lon (None - please mouse over map)',
}
