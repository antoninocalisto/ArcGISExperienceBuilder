export default {
  _widgetLabel: 'consult-filter-criterion-otimization',
  lat: 'Latitude: ',
  lon: 'Longitude: ',
  zoom: 'Zoom',
  latLonWillBeHere: 'Lat/Lon (None - please mouse over map)',
}
