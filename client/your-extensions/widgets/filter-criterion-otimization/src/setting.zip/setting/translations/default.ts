export default {
  _widgetLabel: 'filter-criterion-data-v3x',
  lat: 'Latitude: ',
  lon: 'Longitude: ',
  zoom: 'Zoom',
  latLonWillBeHere: 'Lat/Lon (None - please mouse over map)',
}
