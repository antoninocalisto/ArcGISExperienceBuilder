export default {
  _widgetLabel: 'filter-criterion-otimization-paralel',
  lat: 'Latitude: ',
  lon: 'Longitude: ',
  zoom: 'Zoom',
  latLonWillBeHere: 'Lat/Lon (None - please mouse over map)',
}
